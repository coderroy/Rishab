using Domain;
using Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TestingAPI.Controllers;
using Xunit;

namespace TestingAPI.UnitTest
{
    public class UnitTest1
    {
        [Fact]
        public async Task GetAllEmployees_EmployeesPresent_EmployeeList()
        {
            //Arrange
            var mockRepository = new Mock<IEmployeeRepository>();
            mockRepository.Setup(repo => repo.GetAllEmployee()).ReturnsAsync(GenerateEmployeeList());

            //Act
            ValuesController cont = new ValuesController(mockRepository.Object);

            IActionResult result = await cont.Get();

            OkResult res = result as OkResult;
            //Assert
            //IList<Employee> list = Assert.IsAssignableFrom<IList<Employee>>(res.);
            Assert.Equal(3, result.Count);

        }


        private List<Employee> GenerateEmployeeList()
        {
            return new List<Employee>{

                new Employee
                {
                    EmpID = Guid.NewGuid(),
                    Name = "Ritwick"
                },
                new Employee
                {
                    EmpID = Guid.NewGuid(),
                    Name = "Ritwick Ghosh"
                },
                new Employee
                {
                    EmpID = Guid.NewGuid(),
                    Name = "Rit"
                }    
            };
        }
    }
}
