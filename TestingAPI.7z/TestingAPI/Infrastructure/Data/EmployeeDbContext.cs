﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Data
{
    public class EmployeeDbContext : DbContext
    {
        public EmployeeDbContext(DbContextOptions<EmployeeDbContext> Options) : base(Options)
        {

        }
        
        public DbSet<Employee> Employees { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=TestAPIDb;Integrated Security= true", options =>
            {
                options.MigrationsHistoryTable("_EmployeeMigrationHistory","Empployee");
            });
            base.OnConfiguring(optionsBuilder);
        }
    }
}
