﻿using Domain;
using Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Data
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly EmployeeDbContext _employeeDbContext;
        public EmployeeRepository(EmployeeDbContext Context)
        {
            _employeeDbContext = Context;
        }
        public async Task<List<Employee>> GetAllEmployee()
        {
            return await _employeeDbContext.Set<Employee>().ToListAsync();
        }
        public async Task<Employee> GetEmployeeById(Guid id)
        {
            return await _employeeDbContext.Set<Employee>().FirstOrDefaultAsync(x => x.EmpID == id);
        }
    }
}
