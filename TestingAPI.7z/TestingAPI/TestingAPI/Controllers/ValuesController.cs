﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain;
using Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace TestingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly IEmployeeRepository _employeeRepository;
        public ValuesController(IEmployeeRepository EmployeeRepository)
        {
            _employeeRepository = EmployeeRepository;
        }
        // GET api/values
        [HttpGet]
        public async Task<List<Employee>> Get()
        {
            List<Employee> employeeList= await _employeeRepository.GetAllEmployee();
            return (employeeList);
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] Employee employee)
        {
            _employeeRepository.PostEmployee(employee);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(Guid id, [FromBody] Employee employee)
        {
            _employeeRepository.PutEmployee(employee, id);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(Guid id)
        {
            _employeeRepository.DeleteEmployee(id);
        }
    }
}
