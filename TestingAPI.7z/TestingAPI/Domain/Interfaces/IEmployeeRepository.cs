﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    public interface IEmployeeRepository
    {
        Task<Employee> GetEmployeeById(Guid id);
        Task<List<Employee>> GetAllEmployee();

        void PostEmployee(Employee emp);
        void PutEmployee(Employee emp, Guid id);
        void DeleteEmployee(Guid id);
    }
}
